function [x_mean,x_var,ac,x_corr] = CALCULATE_MOMENTS(series)
   [NOBS,NS] = size(series);

   x_mean = mean(series)';

   vcv = series'*series / NOBS;
   x_var = diag(vcv);
   x_corr = (vcv - x_mean*x_mean') ./ sqrt(x_var*x_var');

   mean1 = mean(series(1:NOBS-1,:))';
   mean2 = mean(series(2:NOBS,:))';
   temp = series(1:NOBS-1,:)'*series(1:NOBS-1,:) / (NOBS-1);
   var1 = diag(temp) - mean1.*mean1;
   temp = series(2:NOBS,:)'*series(2:NOBS,:) / (NOBS-1);
   var2 = diag(temp) - mean2.*mean2;
   ac = (sum(series(1:NOBS-1,:).*series(2:NOBS,:))'/(NOBS-1) ...
        - mean1.*mean2) ./ sqrt(var1.*var2);
end