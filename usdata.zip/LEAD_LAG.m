function [xcorr] = LEAD_LAG(series, ix, NLAG)
   [NOBS,NS] = size(series);
   xcorr = zeros(NS,2*NLAG+1);

   for ilag = -NLAG:NLAG
      index = ilag + NLAG + 1;
      istart = max(1,1-ilag);
      iend = min(NOBS, NOBS-ilag);
      NOBS2 = NOBS - abs(ilag);
      avg1 = mean(series(istart+ilag:iend+ilag,:))';
      avg2 = mean(series(istart:iend,ix))';
      temp = series(istart+ilag:iend+ilag,:)'*series(istart+ilag:iend+ilag,:);
      var1 = diag(temp) / NOBS2 - avg1.*avg1;
      temp = series(istart:iend,ix)'*series(istart:iend,ix);
      var2 = diag(temp) / NOBS2 - avg2.*avg2;

      xcorr(:,index) = (series(istart+ilag:iend+ilag,:)'*series(istart:iend,ix)/NOBS2 - avg1*avg2) ./ sqrt(var1*var2);
   end
end