function y = FIND_DELTA(delta_in)
  global g_k g_kprime g_x;
  y = (1-delta_in(1))^4*g_k + (1-delta_in(1))^3*g_x(1) + ...
      (1-delta_in(1))^2*g_x(2) + (1-delta_in(1))*g_x(3) + g_x(4) - g_kprime;
end
