% Generate date for Gomme, Ravikumar and Rupert (2011), "The
% Return to Capital and the Business Cycle", Review of Economic Dynamics.
%
%@article{grr:returns,
%  author	= {Paul Gomme and B. Ravikumar and Peter Rupert},
%  title		= {The Return to Capital and the Business Cycle},
%  journal	= {Review of Economic Dynamics},
%  year		= {2011},
%  volume	= {14},
%  pages		= {262--278},
%  number	= {2},
%  month		= apr
%}
%
% See also Gomme and Rupert (2007), "Theory, Measurement, and Calibration
% of Macroeconomic Models", Journal of Monetary Economics
%
%@article{gomme/rupert:guide,
%  author	= {Paul Gomme and Peter Rupert},
%  title		= {Theory, Measurement, and Calibration of Macroeconomic
%		  Models},
%  journal	= {Journal of Monetary Economics},
%  year		= {2007},
%  volume	= {54},
%  pages		= {460--497},
%  number	= {2},
%  month		= mar
%}
%
% Finally, see also Gomme and Lkhagvasuren (2013), "Calibration and
% Simulation of DSGE Models", Handbook of Empirical Methods in
% Macroeconomics 
%
%@InCollection{Gomme/Lkhagvasuren:calibration,
%  author	= {Paul Gomme and Damba Lkhagvasuren},
%  title		= {Calibration and Simulation of DSGE Models},
%  booktitle	= {Handbook of Empirical Methods in Macroeconomics},
%  publisher	= {Edward Elgar},
%  year		= {2013},
%  editor	= {Nigar Nasimzade and Michael Thornton},
%  pages		= {575--592},
%  owner		= {pgomme},
%  timestamp	= {2013.08.14}
%}
%

%clear -all;
format short g;

options=optimset('Display', 'off'); 

%Annual = xlsread('us-data.xls','Haver A');
%Quarterly = xlsread('us-data.xls','Haver Q');
Annual = csvread('Haver-A.csv');
Quarterly = csvread('Haver-Q.csv');

[m,n] = size(Annual);

annual.date = 1928+(1:m)';
annual.housing_output = Annual(:,2);
annual.gross_housing_value_added = Annual(:,3);
annual.net_housing_value_added = Annual(:,4);
annual.housing_compensation_of_employees = Annual(:,5);
annual.housing_taxes_on_production = Annual(:,6);
annual.housing_subsidies = Annual(:,7);
annual.housing_net_operating_surplus = Annual(:,8);
annual.housing_net_interest = Annual(:,9);
annual.housing_NOS_transfer_payments = Annual(:,10);
annual.housing_proprietors_income = Annual(:,11);
annual.housing_rental_income = Annual(:,12);
annual.housing_corp_profits = Annual(:,13);
annual.housing_NOS_gov_enterprises = Annual(:,14);
annual.state_local_gov_other_taxes = Annual(:,15);
annual.state_local_gov_property_taxes = Annual(:,16);
annual.compensation_of_employees = Annual(:,17);
annual.gov_wages_and_salaries = Annual(:,18);
annual.rental_income = Annual(:,19);
annual.corporate_profits = Annual(:,20);
annual.net_interest = Annual(:,21);
annual.housing_rental_income = Annual(:,22);
annual.housing_corp_profits = Annual(:,23);
annual.housing_net_interest = Annual(:,24);
annual.GNP = Annual(:,25);
annual.gross_value_added_gov = Annual(:,26);
annual.net_national_product = Annual(:,27);
annual.gov_net_national_product = Annual(:,28);
annual.state_local_property_taxes = Annual(:,29);
annual.net_stock_private_equipment_software = Annual(:,30);
annual.net_stock_private_nonresidential_structures = Annual(:,31);
annual.net_stock_private_residential_structures = Annual(:,32);
annual.net_stock_consumer_durables = Annual(:,33);
annual.net_stock_gov_nonresidential_equipment_software = Annual(:,34);
annual.net_stock_gov_nonresidential_structures = Annual(:,35);
annual.net_stock_gov_residential_structures = Annual(:,36);
annual.PCE_nondurables = Annual(:,37);
annual.PCE_services = Annual(:,38);
annual.real_PCE_nondurables = Annual(:,39);
annual.real_PCE_services = Annual(:,40);
annual.private_inventories = Annual(:,41);
annual.private_inventories_neutral_holding_gains_losses = Annual(:,42);
annual.private_inventores_real_holding_gains_losses = Annual(:,43);
annual.depreciation_private_equipment_software = Annual(:,44);
annual.depreciation_private_nonresidential_structures = Annual(:,45);
annual.depreciation_private_residential_structures = Annual(:,46);
annual.depreciation_gov_equipment_software = Annual(:,47);
annual.depreciation_gov_nonresidential_structures = Annual(:,48);
annual.depreciation_gov_residential_structures = Annual(:,49);
annual.depreciation_consumer_durables = Annual(:,50);
annual.GDP = Annual(:,51);
annual.private_investment_nonresidential_structures = Annual(:,53);
annual.private_investment_equipment_software = Annual(:,54);
annual.private_investment_residential_structures = Annual(:,55);
annual.PCE_durables = Annual(:,56);
annual.private_nonresidential_fixed_investment = Annual(:,57);
annual.real_private_nonresidential_fixed_investment = Annual(:,58);

[m,n] = size(Quarterly);

quarter.date = 1946.75 + (1:m)'/4;
quarter.personal_taxes = Quarterly(:,2);
quarter.gov_taxes_corp_income = Quarterly(:,3);
quarter.state_local_gov_property_taxes = Quarterly(:,4);
quarter.state_local_property_taxes = Quarterly(:,5);
quarter.compensation_of_employees = Quarterly(:,6);
quarter.wage_salary_accruals = Quarterly(:,7);
quarter.net_interest = Quarterly(:,8);
quarter.proprietors_income = Quarterly(:,9);
quarter.rental_income = Quarterly(:,10);
quarter.corp_profits = Quarterly(:,11);
quarter.business_transfer_payments = Quarterly(:,12);
quarter.net_operating_surplus_private = Quarterly(:,13);
quarter.employer_contributions_gov_social_insurance = Quarterly(:,14);
quarter.contributions_gov_social_insurance = Quarterly(:,15);
quarter.consumption_private_fixed_capital = Quarterly(:,17);
quarter.consumption_fixed_capital_business = Quarterly(:,18);
quarter.change_private_inventories = Quarterly(:,19);
quarter.gross_housing_value_added = Quarterly(:,20);
quarter.NBER = Quarterly(:,21);
quarter.SP500_dividends_per_share = Quarterly(:,22);
quarter.SP500_index = Quarterly(:,23);
quarter.CPI_all_items = Quarterly(:,24);
quarter.civilian_noninstitutional_pop_16_plus = Quarterly(:,25);
quarter.PCE_nondurables = Quarterly(:,26);
quarter.PCE_services = Quarterly(:,27);
quarter.real_PCE_nondurables = Quarterly(:,28);
quarter.real_PCE_services = Quarterly(:,29);
quarter.GDP = Quarterly(:,30);
quarter.PCE_housing_services = Quarterly(:,31);
quarter.gov_wages_and_salaries = Quarterly(:,32);
quarter.PCE_housing_services_new = Quarterly(:,33)/1000;
quarter.private_investment_nonresidential_structures = Quarterly(:,34);
quarter.private_investment_equipment_software = Quarterly(:,35);
quarter.private_investment_residential_structures = Quarterly(:,36);
quarter.PCE_durables = Quarterly(:,37);
quarter.hours_private_nonfarm = Quarterly(:,38);
quarter.gov_gross_investment_structures = Quarterly(:,39);
quarter.gov_gross_investment_equipment_software = Quarterly(:,40);
quarter.private_nonresidential_fixed_investment = Quarterly(:,41);
quarter.real_private_nonresidential_fixed_investment = Quarterly(:,42);
quarter.private_inventories = Quarterly(:,43);

quarter.hours_old_lhtpriva = [80108;
			      79880;
			      80193;
			      81309;
			      81673;
			      81243;
			      82021;
			      81400;
			      79611;
			      78052;
			      77174;
			      76173;
			      77072;
			      79762;
			      82855;
			      84277;
			      85749;
			      86295;
			      85821;
			      85833;
			      86864;
			      86214;
			      86936;
			      89243;
			      90176;
			      90430;
			      89652;
			      88286;
			      86536;
			      85866;
			      85337;
			      86301;
			      87745;
			      89619;
			      90551;
			      91622;
			      92184;
			      92095;
			      91437;
			      92608;
			      92661;
			      92000;
			      91499;
			      89802;
			      87634;
			      85928;
			      86902;
			      88467;
			      90456;
			      92320;
			      91723;
			      91875;
			      93041;
			      93032;
			      92387;
			      91273;
			      90258;
			      90494;
			      91459;
			      92525;
			      92944;
			      94332;
			      94499;
			      94368;
			      94653;
			      95732;
			      96132;
			      96539;
			      96782;
			      97884;
			      98538;
			      99635;
			      101022;
			      101947;
			      102782;
			      104292;
			      105879;
			      106843;
			      107649;
			      108163;
			      107937;
			      107592;
			      108330;
			      109161;
			      109403;
			      110414;
			      111566;
			      112320;
			      113478;
			      114545;
			      115420;
			      115515;
			      115001;
			      113884;
			      113005;
			      111738;
			      112066;
			      112549;
			      112517;
			      113745;
			      115032;
			      116436;
			      117146;
			      118849;
			      120585;
			      121858;
			      122443;
			      123449;
			      123375;
			      123237;
			      123203;
			      121327;
			      117477;
			      116424;
			      117819;
			      119459;
			      121425;
			      122071;
			      122486;
			      123206;
			      124525;
			      126746;
			      128152;
			      129632;
			      130175;
			      133632;
			      134893;
			      136342;
			      137676;
			      138043;
			      138916;
			      139358;
			      139343;
			      137028;
			      136357;
			      138308;
			      139617;
			      139457;
			      139627;
			      138867;
			      137386;
			      135935;
			      134728;
			      133556;
			      133898;
			      135637;
			      137880;
			      140694;
			      143067;
			      144765;
			      145949;
			      147134;
			      148057;
			      148791;
			      149421;
			      150463;
			      151161;
			      151035;
			      151625;
			      152372;
			      153963;
			      155158;
			      156679;
			      157774;
			      158735;
			      159951;
			      160972;
			      162455;
			      163564;
			      164037;
			      164288;
			      164813;
			      166059;
			      166134;
			      165667;
			      164546;
			      163030;
			      162260;
			      162496;
			      162423;
			      162064;
			      163165;
			      163324;
			      164365;
			      165436;
			      166653;
			      168011;
			      169496;
			      170641;
			      173060;
			      174580;
			      176175;
			      177057;
			      177279;
			      178242;
			      178998;
			      179596;
			      181458;
			      182971;
			      184464;
			      185961;
			      187584;
			      188985;
			      190758;
			      192261;
			      192946;
			      194065;
			      195379;
			      196072;
			      197139;
			      198386;
			      199815;
			      201113;
			      201418;
			      201618;
			      201787;
			      201746;
			      200987;
			      199697;
			      197803;
			      197486;
			      197433;
			      197034];

N_Q = size(quarter.date,1);
N_A = size(annual.date,1);

%quarter_date = round(quarter.date/10) + (mod(quarter.date,10)-1)/4;
quarter_date = quarter.date;

annual_deflator_consumption = 100 * ...
    (annual.PCE_nondurables+annual.PCE_services) ./ ...
    (annual.real_PCE_nondurables+annual.real_PCE_services); 
annual_deflator_investment = 100 * ...
    annual.private_nonresidential_fixed_investment ./ ...
    annual.real_private_nonresidential_fixed_investment; 
annual_relative_price_investment = annual_deflator_investment ./ ...
    annual_deflator_consumption; 

annual_real_ke = 100 * annual.net_stock_private_equipment_software ./ ...
    annual_deflator_consumption;
annual_real_ks = 100 * annual.net_stock_private_nonresidential_structures ./ ...
    annual_deflator_consumption;
annual_real_kh = 100 * annual.net_stock_private_residential_structures ./ ...
    annual_deflator_consumption;
annual_real_kd = 100 * annual.net_stock_consumer_durables ./ ...
    annual_deflator_consumption;
annual_real_g_ke = 100 * annual.net_stock_gov_nonresidential_equipment_software ./ ...
    annual_deflator_consumption;
annual_real_g_ks = 100 * (annual.net_stock_gov_nonresidential_structures + ...
 annual.net_stock_gov_residential_structures) ./ ...
    annual_deflator_consumption;

annual.delta_ke = NaN(N_A,1);
annual.delta_ke(2:end) = annual.depreciation_private_equipment_software(2:end) ./ ...
    annual.net_stock_private_equipment_software(1:end-1); 

annual.delta_ks = NaN(N_A,1);
annual.delta_ks = annual.depreciation_private_nonresidential_structures(2:end) ./ ...
    annual.net_stock_private_nonresidential_structures(1:end-1); 

annual.delta_kh = NaN(N_A,1);
annual.delta_kh = annual.depreciation_private_residential_structures(2:end) ./ ... 
    annual.net_stock_private_residential_structures(1:end-1); 

annual.delta_kd = NaN(N_A,1);
annual.delta_kd = annual.depreciation_consumer_durables(2:end) ./ ...
    annual.net_stock_consumer_durables(1:end-1); 

annual.delta_g_ke = NaN(N_A,1);
annual.delta_g_ke = annual.depreciation_gov_equipment_software(2:end) ./ ...
    annual.net_stock_gov_nonresidential_equipment_software(1:end-1); 

annual.delta_g_ks = NaN(N_A,1);
annual.delta_g_ks = ...
    annual.depreciation_gov_nonresidential_structures(2:end) ./ ... 
    annual.net_stock_gov_nonresidential_structures(1:end-1); 

annual.delta_g_kh = NaN(N_A,1);
annual.delta_g_kh = annual.depreciation_gov_residential_structures(2:end) ./ ...
    annual.net_stock_gov_residential_structures(1:end-1); 

annual.delta_m = NaN(N_A,1);
annual.delta_m = ...
    (annual.depreciation_private_equipment_software(2:end) ...
     + annual.depreciation_private_nonresidential_structures(2:end)) ./ ...
    (annual.net_stock_private_equipment_software(1:end-1) + ...
     annual.net_stock_private_nonresidential_structures(1:end-1));  

annual.delta_h = NaN(N_A,1);
annual.delta_h = ...
    (annual.depreciation_consumer_durables(2:end) ...
     + annual.depreciation_private_residential_structures(2:end)) ./ ...
    (annual.net_stock_consumer_durables(1:end-1) + ...
     annual.net_stock_private_residential_structures(1:end-1));  

% Annual observation 26: 1954
delta_m = 1-(1-mean(annual.delta_m(26:end))).^(.25);
delta_h = 1-(1-mean(annual.delta_h(26:end))).^(.25);

annual_income_labor = annual.compensation_of_employees - ...
    annual.gov_wages_and_salaries - ...
    annual.housing_compensation_of_employees;
annual_income_capital = annual.rental_income + ...
    annual.corporate_profits + annual.net_interest - ...
    (annual.housing_rental_income + annual.housing_corp_profits + ...
     annual.housing_net_interest) + annual.GNP - ...
    annual.gross_value_added_gov - annual.gross_housing_value_added - ...
    (annual.net_national_product - annual.gov_net_national_product - ...
     annual.net_housing_value_added); 
annual_alpha = annual_income_capital ./ (annual_income_capital + ...
				  annual_income_labor); 
alpha = mean(annual_alpha(26:end-1));
%alpha = 0.283;

% Note discrepancy w.r.t. quarterly y
annual_real_y = annual.GDP ./ (annual_deflator_consumption/100);
annual_real_yp = annual_real_y - annual.gov_wages_and_salaries ./ ...
    (annual_deflator_consumption/100); 
annual_real_xs = annual.private_investment_nonresidential_structures ./ ...
    (annual_deflator_consumption/100); 
annual_real_xe = annual.private_investment_equipment_software ./ ...
    (annual_deflator_consumption/100); 
annual_real_xh = annual.private_investment_residential_structures ./ ...
    (annual_deflator_consumption/100); 
annual_real_xd = annual.PCE_durables ./ (annual_deflator_consumption/100);

annual.xm_y = (annual.private_investment_nonresidential_structures ...
	       + annual.private_investment_equipment_software) ...
               ./ annual.GDP;

annual.xh_y = (annual.private_investment_residential_structures ...
	       + annual.PCE_durables) ./ annual.GDP;

xm_y = mean(annual.xm_y(26:end));
xh_y = mean(annual.xh_y(26:end));

quarter_deflator_consumption = 100 * ...
    (quarter.PCE_nondurables+quarter.PCE_services) ./ ...
    (quarter.real_PCE_nondurables+quarter.real_PCE_services); 
quarter_deflator_investment = 100 * ...
    quarter.private_nonresidential_fixed_investment ./ ...
    quarter.real_private_nonresidential_fixed_investment; 
quarter_relative_price_investment = quarter_deflator_investment ./ ...
    quarter_deflator_consumption; 

% spliced data

quarter_PCE_housing_services = quarter.PCE_housing_services_new;
quarter_PCE_housing_services(1:48) = ...
    quarter.PCE_housing_services(1:48) * ...
    quarter.PCE_housing_services_new(49) / ...
    quarter.PCE_housing_services(49); 

quarter_hours = quarter.hours_private_nonfarm;
quarter_hours(1:68) = quarter.hours_old_lhtpriva(1:68) * ...
    quarter.hours_private_nonfarm(69) / quarter.hours_old_lhtpriva(69);

quarter_real_y = (quarter.GDP  - quarter_PCE_housing_services)./ ...
    (quarter_deflator_consumption/100); 
quarter_real_yp = quarter_real_y - quarter.gov_wages_and_salaries ./ ...
    (quarter_deflator_consumption/100); 
quarter_real_xs = ...
    quarter.private_investment_nonresidential_structures ./ ...
    (quarter_deflator_consumption/100); 
quarter_real_xe = quarter.private_investment_equipment_software ./ ...
    (quarter_deflator_consumption/100); 
quarter_real_xh = quarter.private_investment_residential_structures ./ ...
    (quarter_deflator_consumption/100); 
quarter_real_xd = quarter.PCE_durables ./ (quarter_deflator_consumption/100);
quarter_real_cm = (quarter.PCE_nondurables + quarter.PCE_services - ...
    quarter_PCE_housing_services) ./ (quarter_deflator_consumption/100); 

% Imputed to quarterly
N_I = (N_A-18)*4;
quarter_housing_net_operating_surplus = ...
    [quarter.gross_housing_value_added(1:N_I) .* ...
    kron(annual.housing_net_operating_surplus(19:end) ./ ...
	 annual.gross_housing_value_added(19:end), ones(4,1)); NaN(4,1)];
quarter_housing_net_interest = ...
    [quarter.gross_housing_value_added(1:N_I) .* ...
    kron(annual.housing_net_interest(19:end) ./ ...
	 annual.gross_housing_value_added(19:end), ones(4,1)); NaN(4,1)];
quarter_housing_proprietors_income = ...
    [quarter.gross_housing_value_added(1:N_I) .* ...
    kron(annual.housing_proprietors_income(19:end) ./ ...
	 annual.gross_housing_value_added(19:end), ones(4,1)); NaN(4,1)];
quarter_housing_rental_income = ...
    [quarter.gross_housing_value_added(1:N_I) .* ...
    kron(annual.housing_rental_income(19:end) ./ ...
	 annual.gross_housing_value_added(19:end), ones(4,1)); NaN(4,1)];
quarter_housing_corp_profits = ...
    [quarter.gross_housing_value_added(1:N_I) .* ...
    kron(annual.housing_corp_profits(19:end) ./ ...
	 annual.gross_housing_value_added(19:end), ones(4,1)); NaN(4,1)];

quarter_housing_net_operating_surplus = ...
    quarter_housing_net_operating_surplus(1:N_Q); 
quarter_housing_net_interest = quarter_housing_net_interest(1:N_Q);
quarter_housing_proprietors_income = quarter_housing_proprietors_income(1:N_Q);
quarter_housing_rental_income = quarter_housing_rental_income(1:N_Q);
quarter_housing_corp_profits = quarter_housing_corp_profits(1:N_Q);

quarter_property_taxes_household = quarter.state_local_property_taxes/1000;
quarter_property_taxes_household(1:164) = ...
    kron(annual.state_local_property_taxes(19:59), ones(4,1));
quarter_real_estate_property_taxes = quarter.state_local_gov_property_taxes;
quarter_real_estate_property_taxes(1:44) = ...
    kron(annual.state_local_gov_property_taxes(19:29), ones(4,1));
quarter_other_taxes = [kron(annual.state_local_gov_other_taxes(19:end), ...
			    ones(4,1)); NaN(4,1)];

quarter_other_taxes = quarter_other_taxes(1:N_Q);

global g_k g_kprime g_x;

options=optimset('Display', 'off'); 

quarter_real_ke = NaN(N_Q,1);
quarter_real_depreciation_e = NaN(N_Q,1);
annual_delta_e = NaN(N_A,1);
for ii = 18:N_A-2
  iq = (ii-18)*4;
  g_k = annual_real_ke(ii);
  g_kprime = annual_real_ke(ii+1);
  g_x = quarter_real_xe(iq+1:iq+4);
  annual_delta_e(ii+1) = fsolve(@FIND_DELTA,[.1],options);
  if (ii == 18)
    quarter_real_ke(iq+1) = annual_real_ke(ii);
  end
  for jj = 1:4
    quarter_real_depreciation_e = annual_delta_e(ii+1)*quarter_real_ke(iq+jj);
    quarter_real_ke(iq+1+jj) = ...
	(1-annual_delta_e(ii+1))*quarter_real_ke(iq+jj) + quarter_real_xe(iq+jj);
  end
end

quarter_real_ks = NaN(N_Q,1);
quarter_real_depreciation_s = NaN(N_Q,1);
annual_delta_s = NaN(N_A,1);
for ii = 18:N_A-2
  iq = (ii-18)*4;
  g_k = annual_real_ks(ii);
  g_kprime = annual_real_ks(ii+1);
  g_x = quarter_real_xs(iq+1:iq+4);
  annual_delta_s(ii+1) = fsolve(@FIND_DELTA,[.1],options);
  if (ii == 18)
    quarter_real_ks(iq+1) = annual_real_ks(ii);
  end
  for jj = 1:4
    quarter_real_depreciation_s = annual_delta_s(ii+1)*quarter_real_ks(iq+jj);
    quarter_real_ks(iq+1+jj) = ...
	(1-annual_delta_s(ii+1))*quarter_real_ks(iq+jj) + quarter_real_xs(iq+jj);
  end
end

quarter_real_kh = NaN(N_Q,1);
quarter_real_depreciation_h = NaN(N_Q,1);
annual_delta_h = NaN(N_A,1);
for ii = 18:N_A-2
  iq = (ii-18)*4;
  g_k = annual_real_kh(ii);
  g_kprime = annual_real_kh(ii+1);
  g_x = quarter_real_xh(iq+1:iq+4);
  annual_delta_h(ii+1) = fsolve(@FIND_DELTA,[.1],options);
  if (ii == 18)
    quarter_real_kh(iq+1) = annual_real_kh(ii);
  end
  for jj = 1:4
    quarter_real_depreciation_h = annual_delta_h(ii+1)*quarter_real_kh(iq+jj);
    quarter_real_kh(iq+1+jj) = ...
	(1-annual_delta_h(ii+1))*quarter_real_kh(iq+jj) + quarter_real_xh(iq+jj);
  end
end

quarter_real_kd = NaN(N_Q,1);
quarter_real_depreciation_d = NaN(N_Q,1);
annual_delta_d = NaN(N_A,1);
for ii = 18:N_A-2
  iq = (ii-18)*4;
  g_k = annual_real_kd(ii);
  g_kprime = annual_real_kd(ii+1);
  g_x = quarter_real_xd(iq+1:iq+4);
  annual_delta_d(ii+1) = fsolve(@FIND_DELTA,[.1],options);
  if (ii == 18)
    quarter_real_kd(iq+1) = annual_real_kd(ii);
  end
  for jj = 1:4
    quarter_real_depreciation_d = annual_delta_d(ii+1)*quarter_real_kd(iq+jj);
    quarter_real_kd(iq+1+jj) = ...
	(1-annual_delta_d(ii+1))*quarter_real_kd(iq+jj) + quarter_real_xd(iq+jj);
  end
end

quarter_real_estate_taxes_business = ...
    quarter_real_estate_property_taxes .* quarter_real_ks ./ ...
    (quarter_real_ks + quarter_real_kh);
quarter_real_estate_taxes_household = ...
    quarter_real_estate_property_taxes .* quarter_real_kh ./ ...
    (quarter_real_ks + quarter_real_kh);

quarter_business_income_pre_tax = ...
    quarter.net_operating_surplus_private - ...
    quarter_housing_net_operating_surplus - ...
    (1-alpha)*(quarter.proprietors_income - ...
	       quarter_housing_proprietors_income); 

quarter_tau_h = quarter.personal_taxes ./ ...
    (quarter.wage_salary_accruals + quarter.net_interest + ...
     quarter.proprietors_income + quarter.rental_income);
quarter_tau_n = (quarter_tau_h.*(quarter.wage_salary_accruals + ...
				(1-alpha)*quarter.proprietors_income) ...
		 + quarter.contributions_gov_social_insurance) ./ ...
    (quarter.wage_salary_accruals + ...
     (1-alpha)*quarter.proprietors_income + ...
     quarter.employer_contributions_gov_social_insurance); 

quarter_real_inventories = NaN(N_Q,1);
quarter_real_inventories(1:end-1) = quarter.private_inventories(1:end-1) ./ ...
    (quarter_deflator_consumption(2:end)/100); 

% The following *appears* to have a mistake. Should we be adding in
% *all* real estate property taxes, or only those paid by businesses?
% No, because we can't break down housing income flows between
% busineses and households.

quarter_tau_k_2 = (quarter_tau_h.*(quarter.net_interest + ...
				 alpha*quarter.proprietors_income + ...
				 quarter.rental_income - ...
				 (quarter_housing_net_interest + ...
				  alpha*quarter_housing_proprietors_income ...
				  + quarter_housing_rental_income)) + ...
		 quarter.gov_taxes_corp_income + ...
		 quarter_real_estate_property_taxes + quarter_other_taxes) ./ ...
    (quarter.net_operating_surplus_private ...
      - quarter_housing_net_operating_surplus - ...
     (1-alpha)*(quarter.proprietors_income - ...
		quarter_housing_proprietors_income));  

quarter_tau_k_3 = (quarter_tau_h.*(quarter.net_interest + ...
				 alpha*quarter.proprietors_income + ...
				 quarter.rental_income - ...
				 (quarter_housing_net_interest + ...
				  alpha*quarter_housing_proprietors_income ...
				  + quarter_housing_rental_income)) + ...
		 quarter.gov_taxes_corp_income + ...
		 quarter_real_estate_taxes_business + quarter_other_taxes) ./ ...
    (quarter.net_operating_surplus_private ...
      - quarter_housing_net_operating_surplus - ...
     (1-alpha)*(quarter.proprietors_income - ...
		quarter_housing_proprietors_income));  

quarter_capital_income_taxes = ...
    quarter_tau_h.*(quarter.net_interest + ...
		    alpha*quarter.proprietors_income + ...
		    quarter.rental_income) + ...
    quarter.gov_taxes_corp_income + ...
    quarter_real_estate_property_taxes + quarter_other_taxes;
quarter_capital_income = quarter.net_operating_surplus_private ...
     - (1-alpha)*quarter.proprietors_income;

quarter_tau_k_1 = quarter_capital_income_taxes ./ quarter_capital_income;

quarter_tau_k = quarter_tau_k_3;

tau_k = mean(quarter_tau_k(1:end-5));
tau_n = mean(quarter_tau_n(1:end-5));

quarter_business_income_after_tax = quarter_business_income_pre_tax - ...
    (quarter_tau_h.*(quarter.net_interest + ...
		    alpha*quarter.proprietors_income + ...
		    quarter.rental_income - ...
		    (quarter_housing_net_interest + ...
		     alpha*quarter_housing_proprietors_income + ...
		     quarter_housing_rental_income)) + ...
     quarter.gov_taxes_corp_income + quarter_other_taxes + ...
     quarter_real_estate_taxes_business);

quarter_all_capital_income_pre_tax = ...
    quarter.net_operating_surplus_private - ...
    (1-alpha)*quarter.proprietors_income; 
quarter_all_capital_income_after_tax = ...
    quarter_all_capital_income_pre_tax - ...
    (quarter_tau_h.*(quarter.net_interest + ... 
		    alpha*quarter.proprietors_income + ...
		    quarter.rental_income) + ...
     quarter.gov_taxes_corp_income + quarter_other_taxes + ...
     quarter_real_estate_taxes_business + ...
     quarter_property_taxes_household); 

quarter_real_pc_y = 1000*quarter_real_y ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_yp = 1000*quarter_real_yp ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_cm = 1000*quarter_real_cm ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_xs = 1000*quarter_real_xs ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_xe = 1000*quarter_real_xe ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_xh = 1000*quarter_real_xh ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_xd = 1000*quarter_real_xd ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_ks = 1000*quarter_real_ks ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_ke = 1000*quarter_real_ke ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_kh = 1000*quarter_real_kh ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_real_pc_kd = 1000*quarter_real_kd ./ (quarter.civilian_noninstitutional_pop_16_plus);
quarter_pc_hours = 1000*quarter_hours ./ (quarter.civilian_noninstitutional_pop_16_plus);

quarter_capital_gain = NaN(N_Q,1);
quarter_capital_gain(2:N_Q) = quarter_relative_price_investment(2:end) ...
./ quarter_relative_price_investment(1:end-1); 
mean_capital_gain = mean(quarter_capital_gain(2:end));

quarter_return_business_capital_pre_tax = NaN(N_Q,1);
quarter_return_business_capital_pre_tax(2:end) = ...
    100*((quarter_business_income_pre_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1))+ ...
	  quarter_capital_gain(2:N_Q)).^4 - 1); 
quarter_return_business_capital_after_tax = NaN(N_Q,1);
quarter_return_business_capital_after_tax(2:end) = ...
    100*((quarter_business_income_after_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1))+ ...
	  quarter_capital_gain(2:N_Q)).^4 - 1); 

quarter_return_business_capital_pre_tax_no_gain = NaN(N_Q,1);
quarter_return_business_capital_pre_tax_no_gain(2:end) = ...
    100*((quarter_business_income_pre_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1)) + 1).^4 - 1); 

quarter_return_business_capital_after_tax_no_gain = NaN(N_Q,1);
quarter_return_business_capital_after_tax_no_gain(2:end) = ...
    100*((quarter_business_income_after_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1)) + 1).^4 - 1); 

quarter_return_business_capital_after_tax_constant_gain = NaN(N_Q,1);
quarter_return_business_capital_after_tax_constant_gain(2:end) = ...
    100*((quarter_business_income_after_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1))+ ...
	  mean_capital_gain).^4 - 1); 

quarter_return_all_capital_pre_tax = NaN(N_Q,1);
quarter_return_all_capital_pre_tax(2:end) = ...
    100*((quarter_all_capital_income_pre_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1) + ...
     quarter_real_kh(1:end-1)) + quarter_capital_gain(2:N_Q)).^4 - 1); 

quarter_return_all_capital_after_tax = NaN(N_Q,1);
quarter_return_all_capital_after_tax(2:end) = ...
    100*((quarter_all_capital_income_after_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1) + ...
     quarter_real_kh(1:end-1))+ quarter_capital_gain(2:N_Q)).^4 - 1); 

quarter_return_all_capital_pre_tax_no_gain = NaN(N_Q,1);
quarter_return_all_capital_pre_tax_no_gain(2:end) = ...
    100*((quarter_all_capital_income_pre_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1) + ...
     quarter_real_kh(1:end-1)) + 1).^4 - 1); 

quarter_return_all_capital_after_tax_no_gain = NaN(N_Q,1);
quarter_return_all_capital_after_tax_no_gain(2:end) = ...
    100*((quarter_all_capital_income_after_tax(2:end)/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
    (quarter_real_inventories(1:end-1) ...
     + quarter_real_ks(1:end-1) + quarter_real_ke(1:end-1) + ...
     quarter_real_kh(1:end-1))+ 1).^4 - 1); 

quarter_return_housing_capital_pre_tax = NaN(N_Q,1);
quarter_return_housing_capital_pre_tax(2:end) =  ...
    100*(((quarter_all_capital_income_pre_tax(2:end) - ...
	 quarter_business_income_pre_tax(2:end))/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
	  quarter_real_kh(1:end-1)+ quarter_capital_gain(2:N_Q)).^4 - 1);  

quarter_return_housing_capital_after_tax = NaN(N_Q,1);
quarter_return_housing_capital_after_tax(2:end) =  ...
    100*(((quarter_all_capital_income_after_tax(2:end) - ...
	 quarter_business_income_after_tax(2:end))/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
	  quarter_real_kh(1:end-1)+ quarter_capital_gain(2:N_Q)).^4 - 1);

quarter_return_housing_capital_pre_tax_no_gain = NaN(N_Q,1);
quarter_return_housing_capital_pre_tax_no_gain(2:end) =  ...
    100*(((quarter_all_capital_income_pre_tax(2:end) - ...
	 quarter_business_income_pre_tax(2:end))/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
	  quarter_real_kh(1:end-1)+ 1).^4 - 1);  

quarter_return_housing_capital_after_tax_no_gain = NaN(N_Q,1);
quarter_return_housing_capital_after_tax_no_gain(2:end) =  ...
    100*(((quarter_all_capital_income_after_tax(2:end) - ...
	 quarter_business_income_after_tax(2:end))/4 ./ ...
    (quarter_deflator_consumption(2:end)/100) ./ ...
	  quarter_real_kh(1:end-1)+ 1).^4 - 1);

quarter_solow_residual = NaN(N_Q,1);
%quarter_solow_residual(2:end) = log(quarter_real_y(2:end)) - ...
%    alpha*log(quarter_real_ks(1:end-1)+quarter_real_ke(1:end-1)) - ...
%    (1-alpha)*log(quarter_hours(2:end)); 
quarter_solow_residual(2:end) = (quarter_real_y(2:end) ./ ...
    (quarter_real_ks(1:end-1)+quarter_real_ke(1:end-1)).^alpha).^(1/(1-alpha)) ...
    ./ quarter_hours(2:end); 

% Note: spreadsheet has the wrong values of alpha and delta for the
% "constant" calculations. Pulled off observations starting with 1929,
% not 1947.

quarter_real_dividend = quarter.SP500_dividends_per_share ./ ...
    (quarter_deflator_consumption/100);
quarter_real_SP500_index = quarter.SP500_index ./ ...
    (quarter_deflator_consumption/100);
quarter_real_SP500_return_pre_tax = NaN(N_Q,1);
quarter_real_SP500_return_pre_tax(2:N_Q) = 100*(((quarter_real_dividend(2:end) + ...
	  quarter_real_SP500_index(2:end)) ./ ...
		  quarter_real_SP500_index(1:end-1)).^4 ...
		 - 1);
quarter_real_SP500_return_after_tax = NaN(N_Q,1);
quarter_real_SP500_return_after_tax(2:N_Q) = 100*((((quarter_real_dividend(2:end) + ...
	  quarter_real_SP500_index(2:end)) ./ ...
		  quarter_real_SP500_index(1:end-1) - 1) ...
			.*(1-quarter_tau_k(2:N_Q)) + 1).^4 - 1);

us_data = [quarter_real_pc_y, ...
	   quarter_real_pc_cm, ...
	   (quarter_real_pc_xs+quarter_real_pc_xe + ...
	   quarter_real_pc_xh+quarter_real_pc_xd), ... 
	   (quarter_real_pc_xs+quarter_real_pc_xe), ...
	   (quarter_real_pc_xh+quarter_real_pc_xd), ... 
	   quarter_pc_hours, ...
	   quarter_real_pc_y./quarter_pc_hours, ...
	   (quarter_real_pc_ks+quarter_real_pc_ke + ...
	   quarter_real_pc_kh+quarter_real_pc_kd), ...
	   (quarter_real_pc_ks+quarter_real_pc_ke), ...
	   (quarter_real_pc_kh+quarter_real_pc_kd), ...
	   quarter_solow_residual, ...
	   quarter_relative_price_investment, ...
	   quarter_tau_k, ...
	   quarter_tau_n, ...
	   quarter_return_business_capital_pre_tax, ...
	   quarter_return_business_capital_pre_tax_no_gain, ...
	   quarter_return_business_capital_after_tax, ...
	   quarter_return_business_capital_after_tax_no_gain, ...
	   quarter_return_all_capital_pre_tax, ...
	   quarter_return_all_capital_pre_tax_no_gain, ...
	   quarter_return_all_capital_after_tax, ...
	   quarter_return_all_capital_after_tax_no_gain, ...
	   quarter_return_housing_capital_pre_tax, ...
	   quarter_return_housing_capital_pre_tax_no_gain, ...
	   quarter_return_housing_capital_after_tax, ...
	   quarter_return_housing_capital_after_tax_no_gain, ...
	   quarter_real_SP500_return_pre_tax, ...
	   quarter_real_SP500_return_after_tax];

us_data_star = us_data;

sstrg = strvcat('Output', 'Consumption', 'Investment', 'Investment: market', ...
	 'Investment: home', 'Hours', ...
         'Productivity', 'Capital',  'Capital: market', 'Capital: home', ...
	 'Solow Residual', ...
	 'Price of Investment', 'Capital tax', 'Labor tax', ...
	 'Business capital, pre-tax, capital gain', ...
	 'Business capital, pre-tax, no capital gain', ...
	 'Business capital, after-tax, capital gain', ...
	 'Business capital, after-tax, no capital gain', ...
	 'All capital, pre-tax, capital gain', ...
	 'All capital, pre-tax, no capital gain', ...
	 'All capital, after-tax, capital gain', ...
	 'All capital, after-tax, no capital gain', ...
	 'Housing capital, pre-tax, capital gain', ...
	 'Housing capital, pre-tax, no capital gain', ...
	 'Housing capital, after-tax, capital gain', ...
	 'Housing capital, after-tax, no capital gain', ...
	 'S\&P 500, After-tax Return', 'S\&P 500, Pre-tax Return');

N_END=N_Q-7;
us_data = us_data(29:N_END,:);
us_data_means = mean(us_data);
log_data = log(us_data(:,1:14));
T = size(us_data,1);
hp = HPMATRIX(T, 1600);
hp_data = log_data - hp*log_data;

for ii = 15:size(us_data,2)
  hp_data(:,ii) = (us_data(:,ii)-us_data_means(ii))/us_data_means(ii);
end

[us_mean,us_var,us_ac,us_corr] = CALCULATE_MOMENTS(hp_data);
us_corrlag = LEAD_LAG(hp_data,1,4);

tex_file = fopen('usdata.tex', 'w');

fprintf(tex_file, '\\documentclass[12pt]{article}\n');
fprintf(tex_file, '\\usepackage{graphicx,dcolumn,rotating,multirow,times,mathptmx,booktabs}\n');
fprintf(tex_file, '\\usepackage[margin=1in]{geometry}\n');
fprintf(tex_file, '\\newcolumntype{.}{D{.}{.}{-1}}\n');
fprintf(tex_file, '\\newcolumntype{d}[1]{D{.}{.}{#1}}\n');
fprintf(tex_file, '\\begin{document}\n');
fprintf(tex_file, '\\begin{sidewaystable}\n');
fprintf(tex_file, '\\begin{center}\n');
fprintf(tex_file, '\\caption{U.S.\\@ 1954Q1--2012Q1: Selected Moments}\n');
fprintf(tex_file, '\\label{tab:rbc-lead-lag}\n');
fprintf(tex_file, '\\begin{tabular}{l . . . . . . . . . .}\n');
fprintf(tex_file, '\\toprule\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c }{\\multirow{2}*{\\parbox[t]{1in}{\\centering Standard Deviation}}}\n');
fprintf(tex_file, '\t\t& \\multicolumn{9}{c}{Cross Correlation of Real Output With}\n');
fprintf(tex_file, '\\\\ \\cmidrule{3-11} \n');
fprintf(tex_file, '\t\t&\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_{t-4}$}\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_{t-3}$}\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_{t-2}$}\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_{t-1}$}\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_t$}\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_{t+1}$}\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_{t+2}$}\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_{t+3}$}\n');
fprintf(tex_file, '\t\t& \\multicolumn{1}{c}{$x_{t+4}$}\n');
fprintf(tex_file, '\\\\\n');
fprintf(tex_file, '\\midrule\n');
for ii = 1:size(us_data,2)
   fprintf(tex_file, '%-20s & %8.2f & %8.2f & %8.2f & %8.2f & %8.2f & %8.2f & %8.2f & %8.2f & %8.2f & %8.2f\\\\\n', sstrg(ii,:), 100*sqrt(us_var(ii)), us_corrlag(ii,:));
end
fprintf(tex_file, '\\bottomrule\n');
fprintf(tex_file, '\\end{tabular}\n');
fprintf(tex_file, '\\end{center}\n');
fprintf(tex_file, '\\end{sidewaystable}\n');

fprintf(tex_file, '\\newpage\n');

fprintf(tex_file, '\\begin{table}[htbp]\n');
fprintf(tex_file, '\\centering  \\vskip -1cm\\footnotesize\n');
fprintf(tex_file, '\\caption{U.S.\\@ Return to Capital and Tax Rate on Household Income}\n');
fprintf(tex_file, '\\label{tab:return}\n');
fprintf(tex_file, '\\begin{tabular}{c d{2.2} d{2.2} d{2.2} d{2.2} c d{2.2} d{2.2} d{2.2} d{2.2}} \n');
fprintf(tex_file, '\\toprule\n');
fprintf(tex_file, '& \\multicolumn{4}{c}{Return to Capital} && \\multicolumn{4}{c}{Tax Rate, $\\tau_h$} \\\\\n');
fprintf(tex_file, '\\cmidrule{2-5}  \\cmidrule{7-10}\n');
fprintf(tex_file, 'Year & \\multicolumn{1}{c}{Q1}  & \\multicolumn{1}{c}{Q2} & \\multicolumn{1}{c}{Q3} & \\multicolumn{1}{c}{Q4} && \\multicolumn{1}{c}{Q1}  & \\multicolumn{1}{c}{Q2} & \\multicolumn{1}{c}{Q3} & \\multicolumn{1}{c}{Q4}   \\\\\n');
fprintf(tex_file, '\\midrule\n');

for ii = 1:55
   jj = (ii-1)*4 + 28;
   fprintf(tex_file, '%4i & %6.2f & %6.2f & %6.2f & %6.2f && %6.2f & %6.2f & %6.2f & %6.2f\\\\\n', ii+1953, quarter_return_business_capital_after_tax(jj+1:jj+4), 100*quarter_tau_h(jj+1:jj+4));
end

fprintf(tex_file, '\\bottomrule\n');
fprintf(tex_file, '\\thispagestyle{empty}\n');
fprintf(tex_file, '\\end{tabular}\n');
fprintf(tex_file, '\\end{table}\n');

fprintf(tex_file, '\\begin{table}[htbp]\n');
fprintf(tex_file, '\\centering  \\vskip -1cm\\footnotesize\n');
fprintf(tex_file, '\\caption{U.S.\\@ Tax Rates on Labor and Capital Income}\n');
fprintf(tex_file, '\\label{tab:return}\n');
fprintf(tex_file, '\\begin{tabular}{c d{2.2} d{2.2} d{2.2} d{2.2} c d{2.2} d{2.2} d{2.2} d{2.2}} \n');
fprintf(tex_file, '\\toprule\n');
fprintf(tex_file, '& \\multicolumn{4}{c}{Tax Rate, $\\tau_n$} && \\multicolumn{4}{c}{Tax Rate, $\\tau_k$} \\\\\n');
fprintf(tex_file, '\\cmidrule{2-5}  \\cmidrule{7-10}\n');
fprintf(tex_file, 'Year & \\multicolumn{1}{c}{Q1}  & \\multicolumn{1}{c}{Q2} & \\multicolumn{1}{c}{Q3} & \\multicolumn{1}{c}{Q4} && \\multicolumn{1}{c}{Q1}  & \\multicolumn{1}{c}{Q2} & \\multicolumn{1}{c}{Q3} & \\multicolumn{1}{c}{Q4}   \\\\\n');
fprintf(tex_file, '\\midrule\n');

for ii = 1:55
   jj = (ii-1)*4 + 28;
   fprintf(tex_file, '%4i & %6.2f & %6.2f & %6.2f & %6.2f && %6.2f & %6.2f & %6.2f & %6.2f\\\\\n', ii+1953, 100*quarter_tau_n(jj+1:jj+4), 100*quarter_tau_k(jj+1:jj+4));
end

fprintf(tex_file, '\\bottomrule\n');
fprintf(tex_file, '\\thispagestyle{empty}\n');
fprintf(tex_file, '\\end{tabular}\n');
fprintf(tex_file, '\\end{table}\n');


fprintf(tex_file, '\\end{document}\n');

fclose(tex_file);

data_file = fopen('usdata.dat', 'w');
fprintf(data_file, '%8.2f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n',...
[quarter_date, ...
 quarter_return_business_capital_pre_tax, ...
 quarter_return_business_capital_pre_tax_no_gain, ...
 quarter_return_business_capital_after_tax, ...
 quarter_return_business_capital_after_tax_no_gain, ...
 quarter_return_all_capital_pre_tax, ...
 quarter_return_all_capital_pre_tax_no_gain, ...
 quarter_return_all_capital_after_tax, ...
 quarter_return_all_capital_after_tax_no_gain, ...
 quarter_return_housing_capital_pre_tax, ...
 quarter_return_housing_capital_pre_tax_no_gain, ...
 quarter_return_housing_capital_after_tax, ...
 quarter_return_housing_capital_after_tax_no_gain]'); 
fclose(data_file);

data_file = fopen('shocks.csv', 'w');
fprintf(data_file, 'date,rprice,solow_lev,tau_n_lev,tau_k_lev,dum82\n');
fprintf(data_file, '%8.2f,%16.10f,%16.10f,%16.10f,%16.10f,%16.10f\n', ...
	[quarter_date, quarter_relative_price_investment, ...
	 quarter_solow_residual, quarter_tau_n, quarter_tau_k, quarter_date>1982.6]'); 
fclose(data_file);

if exist('OCTAVE_VERSION') ~= 0
    i_start = 29;
    i_end = size(quarter_date,1)-6;
    y = log(quarter_solow_residual(i_start:i_end));
    n = i_end - i_start + 1;
    x = [ones(n,1), log(quarter_solow_residual(i_start-1:i_end-1)), (1:n)'];
    [beta_hat, var_resid, resid] = ols(y,x);
    beta_vcv = var_resid * inv(x'*x);
    beta_se = sqrt(diag(beta_vcv));
    printf('constant     %20.16f %20.16f\n', beta_hat(1), beta_se(1));
    printf('lag          %20.16f %20.16f\n', beta_hat(2), beta_se(2));
    printf('time         %20.16f %20.16f\n', beta_hat(3), beta_se(3));
    printf('SE(residual) %20.16f\n', sqrt(var_resid));
end
