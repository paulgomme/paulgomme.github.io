function [hpmat] = HPMATRIX(T, lambda)
   d = (1+6*lambda)*ones(T,1);
   x = diag(d);
   d = -4*lambda*ones(T-1,1);
   x = x + diag(d,1) + diag(d,-1);
   d = lambda*ones(T-2,1);
   x = x + diag(d,2) + diag(d,-2);
   x(1,1) = 1+lambda;
   x(1,2) = -2*lambda;
   x(2,1) = -2*lambda;
   x(2,2) = 1+5*lambda;
   x(T,T) = 1+lambda;
   x(T-1,T) = -2*lambda;
   x(T,T-1) = -2*lambda;
   x(T-1,T-1) = 1+5*lambda;
   hpmat = inv(x);
end